export class Emp{
    empno:number
    ename:string
    salary:number
}