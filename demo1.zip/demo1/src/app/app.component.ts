import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demo1';
  filename="assets/logo1.png";
  method1(){
    console.log("method1 invoked ...")
    this.title = "AA"
    this.filename = this.filename == "assets/logo1.png"
       ?"assets/logo2.png" : "assets/logo1.png";
  }
}
